# EAInstallationInspector

Source code for the [EXploringEA.com's](http://EXploringEA.com "EXploringEA") EA Installation Inspector 

This is a windows application which displays registry entries associated with Sparxsystems EA Addins.
For more information review the document **eaInstallationInspectorInformationV5.pdf** located under the resources directory.

Current release is V6 - this has the functionality of previous versions with single addition of a EA.exe debug config file.

A pre-built .exe and help file are provuded at the root level.

NOTE: This code is released under the terms of the GPL3 licence agreement.

For more information about the EA Installation Inspector and AddIn Installation errors check out - http://tools.exploringea.co.uk/index.php?n=EaInspector.Overview
